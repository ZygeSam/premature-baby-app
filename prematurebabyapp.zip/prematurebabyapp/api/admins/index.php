<?php
require_once('../App/Admin.php');

use App\Admin;

$admins = new Admin();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_SERVER['QUERY_STRING'])) {
        if (is_null($admins->showAdmin($_GET['id']))) {
            return "No record available";
        } else {
            print_r($admins->showAdmin($_GET['id']));
        }

        die;
    }
    print_r($admins->getAllAdmins());
}

if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    if (isset($_SERVER['QUERY_STRING'])) {
        if (is_null($admins->showAdmin($_GET['id']))) {
            echo "No record available";
        } else {
            $data = file_get_contents('php://input');
            $Decode_Data = json_decode($decode, true);
            if ($admins->updateAdmin($Decode_Data) == true) {
                return "Admin updated";
            } else {
                return "Could not update Admin";
            }
        }

        die;
    }
    print_r($admins->getAllAdmins());
}
