<?php

namespace App;

use App\Conn\Database;
use PDO;

require_once('../Conn/Database.php');

class BabyParent extends Database
{
    protected $table = 'parents';
    protected $db;
    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAllParents()
    {
        return $this->db->index($this->table);
    }

    public function showParent($id)
    {
        return $this->db->show($id, $this->table);
    }

    public function updateParent($request)
    {
        $stmt = $this->pdo->prepare("Update {$this->table}
                                     SET 
                                     username = '',
                                     password = '',
                                     email = ''
									 WHERE email = :email OR username= :user");
    }

    public function delParent($id)
    {
        return $this->db->delete($id, $this->table);
    }

    public function loginParent($request)
    {
        return $this->db->login($request, $this->table);
    }

    public function register($request)
    {
        return $this->db->registerParent($request);
    }
}
