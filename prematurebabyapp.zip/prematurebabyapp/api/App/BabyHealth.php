<?php

namespace App;

use App\Conn\Database;

require_once('../Conn/Database.php');

class BabyHealth
{
    protected $table = 'babies-health';
    protected $db;
    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAllBabiesHealth()
    {
        return $this->db->index($this->table);
    }

    public function createBabyHealth($request)
    {
        return $this->db->addBabyHealth($request);
    }

    public function showBabyHealth($id)
    {
        return $this->db->showBabyHealth($id);
    }

    public function updateBabyHealth($request)
    {
        $stmt = $this->pdo->prepare("Update {$this->table}
                                     SET 
                                     username = '',
                                     password = '',
                                     email = ''
									 WHERE email = :email OR username= :user");
    }

    public function delBabyHealth($id)
    {
        return $this->db->delete($id, $this->table);
    }
}
