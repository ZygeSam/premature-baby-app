<?php

namespace App\Models;

use Database;
use PDO;

require_once('./conn/Database.php');

class Post
{
    protected $table = 'blogPosts';
    protected $db;
    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAllPosts()
    {
        return $this->db->index($this->table);
    }

    public function createPosts($request)
    {
        # code...
    }

    public function showPost($id)
    {
        return $this->db->show($id, $this->table);
    }

    public function updatePost($request)
    {
        $stmt = $this->pdo->prepare("Update {$this->table}
                                     SET 
                                     username = '',
                                     password = '',
                                     email = ''
									 WHERE email = :email OR username= :user");
    }

    public function delPost($id)
    {
        return $this->db->delete($id, $this->table);
    }
}
