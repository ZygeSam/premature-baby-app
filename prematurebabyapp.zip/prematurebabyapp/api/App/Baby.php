<?php

namespace App;

use App\Conn\Database;

require_once('../Conn/Database.php');

class Baby
{
    protected $table = 'babies';
    protected $db;
    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAllBabies($id)
    {
        return $this->db->showParentBabies($id);
    }

    public function createBaby($request)
    {
        return $this->db->addBaby($request);
    }

    public function showBaby($id)
    {
        return $this->db->show($id, $this->table);
    }
    public function showBabyByParent($id)
    {
        return $this->db->showParentBabies($id);
    }

    public function updateBaby($request)
    {
        $stmt = $this->pdo->prepare("Update {$this->table}
                                     SET 
                                     username = '',
                                     password = '',
                                     email = ''
									 WHERE email = :email OR username= :user");
    }

    public function delBaby($id)
    {
        return $this->db->delete($id, $this->table);
    }
}
