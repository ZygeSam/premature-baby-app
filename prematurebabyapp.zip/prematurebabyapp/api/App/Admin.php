<?php

namespace App;

use App\Conn\Database;

require_once('../Conn/Database.php');


class Admin
{
    protected $table = 'admins';
    protected $db;
    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAllAdmins()
    {
        print_r($this->db->index($this->table));
    }

    public function showAdmin($id)
    {
        return $this->db->show($id, $this->table);
    }

    public function updateAdmin($request)
    {
        $stmt = $this->pdo->prepare("Update {$this->table}
                                     SET 
                                     username = '',
                                     password = '',
                                     email = ''
									 WHERE email = :email OR username= :user");
        $stmt->bindValue(":email", $request['email']);
        $stmt->bindValue(":user", $request['user']);
        if ($stmt->execute()) {
            return true;
        }
    }

    public function delAdmin($id)
    {
        return $this->db->delete($id, $this->table);
    }

    public function loginAdmin($request)
    {
        return $this->db->login($request, $this->table);
    }

    public function registerAdmin($request)
    {
        $stmt = $this->pdo->prepare("Select * from {$this->table}
									WHERE email = :email OR username= :user");
        $request['pwd'] = password_hash($request['pwd'], PASSWORD_DEFAULT);
        $stmt->bindValue(":email", $request['email']);
        $stmt->bindValue(":user", $request['user']);
        if ($stmt->execute()) {
            if ($stmt->rowcount() == 1) {
                return ["message" => "Username or Email already exists"];
            } else {
                $stmt = $this->pdo->prepare("Insert Into {$this->table}(email, username, password)
									Values(:email, :user, :pwd)");
                $request['pwd'] = password_hash($request['pwd'], PASSWORD_DEFAULT);
                $stmt->bindValue(":email", $request['email']);
                $stmt->bindValue(":user", $request['user']);
                $stmt->bindValue(":pwd", $request['pwd']);
                $stmt->execute();
            }
        }
    }
}
