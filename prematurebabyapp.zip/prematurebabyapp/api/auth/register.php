<?php
echo "Helo";
require_once('../App/Admin.php');


use App\Admin;

$admins = new Admin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = file_get_contents('php://input');
    $Decode_Data = json_decode($decode, true);
    $admins->registerAdmin($Decode_Data);
}else{
    echo "wrong request method";
}
