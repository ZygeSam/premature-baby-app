<?php
require_once('../App/BabyParent.php');

use App\BabyParent;

$parents = new BabyParent();


if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_SERVER['QUERY_STRING']) && isset($_GET['id'])) {
        if (is_null($parents->showParent($_GET['id']))) {
            echo "No record available";
        } else {
            print_r($parents->showParent($_GET['id']));
        }

        die;
    }
    if (is_null($parents->getAllParents())) {
        echo "No record Found";
    } else {
        print_r($parents->getAllParents());
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    if (isset($_SERVER['QUERY_STRING'])) {
        if (is_null($parents->showParent($_GET['id']))) {
            echo "No record available";
        } else {
            $data = file_get_contents('php://input');
            $Decode_Data = json_decode($decode, true);
            if ($parents->updateParent($Decode_Data) == true) {
                return "Parent updated";
            } else {
                return "Could not update Parent";
            }
        }

        die;
    }
}
