 <?php
    require_once('../App/BabyHealth.php');

    use App\BabyHealth;

    $babyHealth = new BabyHealth();

    if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        if (isset($_SERVER['QUERY_STRING'])) {
            if (is_null($babyHealth->showBabyHealth($_GET['id']))) {
                echo "No record available";
            } else {
                echo json_encode($babyHealth->showBabyHealth($_GET['id']));
            }

            die;
        }
        echo json_encode($babyHealth->getAllBabiesHealth());
    }
