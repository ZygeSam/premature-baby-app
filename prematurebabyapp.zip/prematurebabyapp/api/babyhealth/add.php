<?php
require_once('../App/BabyHealth.php');

use App\BabyHealth;

$babies = new BabyHealth();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = file_get_contents('php://input');

    $Decode_Data = json_decode($data, true);
    echo $babies->createBabyHealth($Decode_Data);
}
