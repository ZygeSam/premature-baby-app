<?php

namespace App\Conn;

use PDO;

class Database
{
    protected $pdo;

    public function __construct()
    {
        try {
            $this->pdo = new PDO("mysql:server=localhost;dbname=prematurebaby", "root", "");
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $e) {
            echo ("Connection failed");
        }
    }

    public function index($table)
    {
        $stmt = $this->pdo->prepare("Select * from $table");
        if ($stmt->execute()) {
            if ($stmt->rowcount() > 0) {
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    }

    public function show($id, $table)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE id = :id");
        $stmt->bindValue(":id", $id);
        if ($stmt->execute()) {
            if ($stmt->rowcount() == 1) {
                return $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }
    }

    public function delete($id, $table)
    {
        $stmt = $this->pdo->prepare("Delete from $table
									Where id= :id");
        $stmt->bindValue(':id', $id);
        return $stmt->execute();
    }


    public function login($request, $table)
    {
        $stmt = $this->pdo->prepare("Select * from $table
									WHERE username = :user");

        $request['username'] = trim($request['username']);

        $stmt->bindValue(':user', $request['username']);

        if ($stmt->execute()) {
            if ($stmt->rowcount() == 1) {
                if ($row = $stmt->fetch()) {
                    if (password_verify($request['password'], $row['password'])) {
                        return json_encode(
                            [
                                "message" => "Loggedin Successfully",
                                "data" => [
                                    "id" => $row['id'],
                                    "firstname" => $row['firstname'],
                                    "lastname" => $row['lastname'],
                                    "user" => $row['username'],
                                    "password" => $row['password'],

                                ]
                            ]
                        );
                    } else {
                        return json_encode(["message" => "Wrong password"]);
                    }
                } else {
                    return json_encode(["message" => "Could not fetch"]);
                }
            } else {
                return json_encode(["message" => "No Account found with username"]);
            }
        } else {
            return json_encode(["message" => "Oops something happened"]);
        }
    }

    public function registerParent($request)
    {
        $stmt = $this->pdo->prepare("Select * from parents WHERE  username = :username");
        $stmt->bindValue(":username", $request['username']);
        if ($stmt->execute()) {
            if ($stmt->rowcount() == 1) {
                return json_encode("Username already exists");
            } else {
                $stmt = $this->pdo->prepare("Insert Into parents (firstname, lastname, username, password)
									Values(:firstname, :lastname, :user, :pwd)");
                $request['password'] = password_hash($request['password'], PASSWORD_BCRYPT);
                $stmt->bindValue(":firstname", $request['firstname']);
                $stmt->bindValue(":lastname", $request['lastname']);
                $stmt->bindValue(":user", $request['username']);
                $stmt->bindValue(":pwd", $request['password']);
                if ($stmt->execute()) {
                    return json_encode("Parent Created Successfully");
                }
            }
        }
    }

    public function addBaby($request)
    {

        $stmt = $this->pdo->prepare("Insert Into babies (name, age, parent_id)
									Values(:name, :age, :parent_id)");
        $stmt->bindValue(":name", $request['name']);
        $stmt->bindValue(":age", $request['age']);
        $stmt->bindValue(":parent_id", $request['parent_id']);
        if ($stmt->execute()) {
            return json_encode("Baby created Successfully");
        }
    }


    public function addBabyHealth($request)
    {

        $stmt = $this->pdo->prepare("Insert Into babieshealth (baby_id, weight, height, feeding, temperature)
									Values(:baby_id, :weight, :height, :feeding, :temperature)");

        $stmt->bindValue(":baby_id", $request['baby_id']);
        $stmt->bindValue(":weight", $request['weight']);
        $stmt->bindValue(":height", $request['height']);
        $stmt->bindValue(":feeding", $request['feeding']);
        $stmt->bindValue(":temperature", $request['temperature']);
        if ($stmt->execute()) {
            return json_encode("BabyHealth Info created Successfully");
        }
    }

    public function showParentBabies($id)
    {
        $stmt = $this->pdo->prepare("Select * from babies where parent_id = :parent_id");
        $stmt->bindValue(":parent_id", $id);
        if ($stmt->execute()) {
            if ($stmt->rowcount() == 0) {
                return json_encode(["data" => "No array exist"]);
            } else {
                return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            }
        }
    }

    public function showBabyHealth($id)
    {
        $stmt = $this->pdo->prepare("Select * from babieshealth where baby_id = :baby_id");
        $stmt->bindValue(":baby_id", $id);
        if ($stmt->execute()) {
            if ($stmt->rowcount() == 0) {
                return json_encode("No array exist");
            } else {
                return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            }
        }
    }

    public function countBabies($id)
    {
        $stmt = $this->pdo->prepare("Select Count(*) from babies where parent_id = :parent_id");
        $stmt->bindValue(":parent_id", $id);
        if ($stmt->execute()) {
            if ($stmt->rowcount() == 0) {
                return json_encode("No array exist");
            } else {
                return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            }
        }
    }
}
