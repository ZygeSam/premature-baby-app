<?php
require_once('../App/Baby.php');

use App\Baby;

$babies = new Baby();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = file_get_contents('php://input');
    $Decode_Data = json_decode($data, true);
    echo $babies->createBaby($Decode_Data);
}
