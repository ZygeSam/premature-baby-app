<?php
require_once('../App/Baby.php');

use App\Baby;

$babies = new Baby();


if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_SERVER['QUERY_STRING']) && isset($_GET['id'])) {
        if (is_null($babies->showBaby($_GET['id']))) {
            echo json_encode("No record available");
        } else {
            echo json_encode($babies->showBaby($_GET['id']));
        }

        die;
    }
    if (isset($_SERVER['QUERY_STRING']) && isset($_GET['parent_id'])) {
        if (is_null($babies->getAllBabies($_GET['parent_id']))) {
            echo json_encode("No record available");
        } else {
            echo json_encode($babies->getAllBabies($_GET['parent_id']));
        }

        die;
    }
}
