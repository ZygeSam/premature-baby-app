<?php
require_once('../App/BabyParent.php');

use App\BabyParent;

$parents = new BabyParent();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = file_get_contents('php://input');
    $Decode_Data = json_decode($data, true);
    echo $parents->loginParent($Decode_Data);
}
